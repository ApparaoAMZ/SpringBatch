package com.javasampleapproach.batchcsvpostgresql.dao.impl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.javasampleapproach.batchcsvpostgresql.dao.ApplicationDao;
import com.javasampleapproach.batchcsvpostgresql.model.Application;
import com.javasampleapproach.batchcsvpostgresql.model.Customer;

@Repository
public class ApplicationDaoImpl extends JdbcDaoSupport implements ApplicationDao {

	@Autowired
	DataSource dataSource;

	@PostConstruct
	private void initialize() {
		setDataSource(dataSource);
	}

	@Override
	public void UpdateBatch(List<? extends Application> Applications) {
				
	    String sql = "UPDATE heroku_depersonalisation.application__c set candidate__c=? , felony_conviction_question_1__c=? , requisition_hiring_function__c=? , national_id_country_ps__c=? , candidate_withdraws_detail__c=?  WHERE id=?";
	    int[] updateCounts=getJdbcTemplate().batchUpdate(sql, new BatchPreparedStatementSetter() {
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				Application application = Applications.get(i);
				 ps.setString(1,Applications.get(i).getCandidate());
                 ps.setString(2,Applications.get(i).getFelony_conviction_question());
					ps.setString(3, Applications.get(i).getRequisition_hiring_function());
					ps.setString(4,Applications.get(i).getNational_id_country_ps_c());
					ps.setString(5, Applications.get(i).getCandidate_withdraws_detail_c());
                 ps.setInt(6, Applications.get(i).getId());
			}

			public int getBatchSize() {
				return Applications.size();
			}
		});

	}

	
}
