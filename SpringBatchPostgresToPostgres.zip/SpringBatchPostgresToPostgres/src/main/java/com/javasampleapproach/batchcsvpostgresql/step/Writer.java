package com.javasampleapproach.batchcsvpostgresql.step;

import java.util.List;

import org.springframework.batch.item.ItemWriter;

import com.javasampleapproach.batchcsvpostgresql.dao.ApplicationDao;
import com.javasampleapproach.batchcsvpostgresql.model.Application;
import com.javasampleapproach.batchcsvpostgresql.model.Customer;

public class Writer implements ItemWriter<Application> {

	private final ApplicationDao applicationDao;

	public Writer(ApplicationDao applicationDao) {
		this.applicationDao = applicationDao;
	}

	@Override
	public void write(List<? extends Application> applications) throws Exception {
		//System.out.println("applications::"+applications);
		applicationDao.UpdateBatch(applications);
		//System.out.println("Done::");
	}

}
