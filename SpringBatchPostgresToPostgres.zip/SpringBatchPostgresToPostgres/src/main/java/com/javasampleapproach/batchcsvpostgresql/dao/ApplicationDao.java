package com.javasampleapproach.batchcsvpostgresql.dao;

import java.util.List;

import com.javasampleapproach.batchcsvpostgresql.model.Application;


public interface ApplicationDao {
	public void UpdateBatch(List<? extends Application> customers);
	
}
